import axios from 'axios';

const FetchQuestions = async (prompt) => {
  const API_KEY = process.env.REACT_APP_OPENAI_API_KEY;

  const response = await axios.post(
    'https://api.openai.com/v1/engines/davinci-codex/completions',
    {
      prompt: prompt,
      max_tokens: 150,
      n: 5, // Number of questions to generate
      stop: ["\n"],
    },
    {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data.choices.map(choice => {
    const [questionText, ...optionsText] = choice.text.trim().split('\n');
    const options = optionsText.reduce((acc, line) => {
      const [key, ...value] = line.split(' ');
      acc[key] = value.join(' ');
      return acc;
    }, {});
    return {
      question: questionText,
      options
    };
  });
};

export default FetchQuestions;
