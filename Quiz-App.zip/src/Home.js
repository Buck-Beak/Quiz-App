import QuestionList from "./QuestionList";
//import UseFetch from "./UseFetch";

const Home = () => {
    //const {data:questions} = UseFetch("http://localhost:8000/questions");
    //{questions && <QuestionList questions = {questions}/>}
    return ( 
        <div className="home">
            <h1>Welcome!!</h1>
            <QuestionList />
        </div>
     );
}
 
export default Home;