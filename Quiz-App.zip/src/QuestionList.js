import FetchQuestions from "./FetchQuestions";
import { useState,useEffect } from 'react';
/*{questions.map(questions=>(
                <div className="ques-option" key = {questions.id}>
                    <h2>{questions.question}</h2>
                    <input type="radio" id="op1" name="option"/>
                    <label htmlFor="op1">{questions.options.op1}</label>
                    <input type="radio" id="op2" name="option" />
                    <label htmlFor="op2">{questions.options.op2}</label>
                    <input type="radio" id="op3" name="option" />
                    <label htmlFor="op3">{questions.options.op3}</label>
                    <input type="radio" id="op4" name="option" />
                    <label htmlFor="op4">{questions.options.op4}</label>
                </div>
))}*/
const QuestionList = () => {
    const [questions, setQuestions] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchQuestions = async () => {
        const prompt = "Generate quiz questions with four options";
        try {
            const generatedQuestions = await FetchQuestions(prompt);
            setQuestions(generatedQuestions);
        } catch (error) {
            console.error("Error fetching questions:", error);
        } finally {
            setLoading(false);
        }
        };

        fetchQuestions();
    }, []);

    if (loading) return <div>Loading...</div>;
    return ( 
        <div className="questionlist">
            {questions.map((question, index) => (
                <div className="ques-option" key={index}>
                <h2>{question.question}</h2>
                {Object.entries(question.options).map(([key, option]) => (
                    <div key={key}>
                    <input type="radio" id={key} name={`question-${index}`} value={key} />
                    <label htmlFor={key}>{option}</label>
                    </div>
                ))}
        </div>
      ))}
           
        </div>
     );
}
 
export default QuestionList;